import json
import random
import time
from kafka import KafkaProducer

# Kafka Configuration
KAFKA_BROKER = 'localhost:9092'  # Replace with your Kafka broker
TOPIC = 'OMNIS.performance'

# Initialize Kafka Producer
producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

def generate_traffic_data():
    """Simulates basic network traffic data."""
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())
    data = {
        "timestamp": timestamp,
        "interface": "eth0",
        "bytes_sent": random.randint(1000, 100000),
        "bytes_recv": random.randint(1000, 100000),
        "packets_sent": random.randint(10, 1000),
        "packets_recv": random.randint(10, 1000),
        "drop_in": random.randint(0, 10),
        "drop_out": random.randint(0, 10)
    }
    return data

def main():
    try:
        while True:
            # Generate and send simulated traffic data
            traffic_data = generate_traffic_data()
            print(f"Sending data: {traffic_data}")
            producer.send(TOPIC, value=traffic_data)
            producer.flush()
            time.sleep(2)  # Adjust the interval as needed
    except KeyboardInterrupt:
        print("\nSimulation stopped.")
    finally:
        producer.close()

if __name__ == "__main__":
    main()
