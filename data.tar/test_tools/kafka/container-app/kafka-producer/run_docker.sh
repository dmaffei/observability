#!/bin/bash

# Run the Kafka producer container
docker run -d --name kafka-producer kafka-producer

