#!/bin/bash

# Stop the Kafka producer container
docker stop kafka-producer
