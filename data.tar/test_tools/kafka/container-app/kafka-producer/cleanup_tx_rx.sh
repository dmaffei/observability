docker rm kafka-producer
docker rmi kafka-producer
