#!/bin/bash

# Build the Docker image
docker build -t kafka-producer .
