from kafka import KafkaProducer
import json
import time
import random

# Kafka configurations
KAFKA_BOOTSTRAP_SERVERS = '10.8.8.104:9092'  # Change this to your Kafka broker address
KAFKA_TOPIC = 'OMNIS.performance'

message_to_send = {
    "timestamp": "2024-07-04 14:30:00.000000 UTC",
    "server_host_ip_address": "135.84.172.154",
    "server_port": 443,
    "client_host_ip_address": "192.168.0.0",
    "vlan_id": None,
    "application_name": "WebEx",
    "ai_sensor_ip_address": "192.168.30.99",
    "ai_sensor_name": "vstream99:if3",
    "ai_sensor_interface_number": 3,
    "to_server_packets": 284,
    "from_server_packets": 363,
    "to_server_octets": 67458,
    "from_server_octets": 216164
}

def send_message():
    try:
        producer = KafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            value_serializer=lambda x: json.dumps(x).encode('utf-8')
        )
        while True:
            # Send the message
            producer.send(KAFKA_TOPIC, value=message_to_send)
            producer.flush()
            print(f"Message sent: {message_to_send}")

            # Wait for a random interval between 300ms and 3 seconds
            time.sleep(random.uniform(0.3, 3))
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    send_message()
