#!/usr/bin/env python3 
"""
InfluxDB Statistics Test Script

This script connects to an InfluxDB instance, ensures the specified bucket exists (creating it if necessary),
writes multiple test data points with random values and incremented timestamps to the bucket, and then
queries statistics for specified fields to verify successful data ingestion and retrieval.

Additionally, it logs all data sent to InfluxDB to a log file with detailed information, and ensures that
timestamps are sent with nanosecond precision.

Configuration:
- INFLUX_HOST: InfluxDB server IP or hostname.
- INFLUX_PORT: InfluxDB server port (default: 8086).
- INFLUX_TOKEN: InfluxDB authentication token.
- INFLUX_ORG_ID: InfluxDB organization ID.
- INFLUX_BUCKET: InfluxDB bucket name.

Usage:
    python fill_influxDB_dummy_data.py
"""

import sys
import time
import random
import logging
from datetime import datetime, timezone, timedelta

from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

# === InfluxDB Configuration ===
INFLUX_HOST = "10.8.8.104"
INFLUX_PORT = "8086"  # Default InfluxDB port
INFLUX_TOKEN = "MyInfluxToken123"
INFLUX_ORG_ID = "e02569c0476f2dd0"
INFLUX_BUCKET = "telegraf_OMNIS.netops" 

# === Fields to Test ===
FIELDS_TO_TEST = [
    "to_server_packets",
    "from_server_packets",
    "to_server_octets",
    "from_server_octets",
    "client_min_window_size",
    "server_min_window_size",
    "sum_of_client_latency",
    "sum_of_server_latency",
    "client_latency_count",
    "server_latency_count",
    "client_ack_retransmissions_count",
    "server_ack_retransmissions_count"
]

# === Number of Test Points ===
NUM_TEST_POINTS = 300  # Adjust as needed for meaningful statistics 

# === Retention Policy (in seconds) ===
# Example: 30 days
RETENTION_SECONDS = 30 * 24 * 60 * 60  # 30 days

# === Logging Configuration ===
LOG_FILE = "influxdb_test.log"

# Configure the logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)  # Set to DEBUG to capture all levels of logs

# Create handlers
file_handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
file_handler.setLevel(logging.DEBUG)  # Capture all logs to the file

stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setLevel(logging.INFO)  # Adjust as needed (INFO level to reduce verbosity)

# Create formatters
formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
file_handler.setFormatter(formatter)
stream_handler.setFormatter(formatter)

# Add handlers to the logger
logger.addHandler(file_handler)
logger.addHandler(stream_handler)

# === Helper Functions ===

def generate_random_field_values():
    """
    Generates a dictionary of field values with random integers.
    Modify the ranges as per realistic expectations for your data.
    """
    return {
        "to_server_packets": random.randint(0, 1000),
        "from_server_packets": random.randint(0, 1000),
        "to_server_octets": random.randint(0, 100000),
        "from_server_octets": random.randint(0, 100000),
        "client_min_window_size": random.randint(0, 1000),
        "server_min_window_size": random.randint(0, 1000),
        "sum_of_client_latency": random.randint(0, 10000),
        "sum_of_server_latency": random.randint(0, 10000),
        "client_latency_count": random.randint(0, 100),
        "server_latency_count": random.randint(0, 100),
        "client_ack_retransmissions_count": random.randint(0, 50),
        "server_ack_retransmissions_count": random.randint(0, 50)
    }

def datetime_to_epoch_ns(dt: datetime) -> int:
    """
    Converts a datetime object to an integer representing nanoseconds since epoch.

    Args:
        dt (datetime): The datetime object to convert. Must be timezone-aware (UTC).

    Returns:
        int: Nanoseconds since epoch.
    """
    return int(dt.timestamp() * 1_000_000_000)

def ensure_bucket_exists(client: InfluxDBClient, bucket_name: str, org_id: str, retention_seconds: int) -> bool:
    """
    Checks if the specified bucket exists. If not, creates it with the given retention period.

    Args:
        client (InfluxDBClient): The InfluxDB client instance.
        bucket_name (str): The name of the bucket to check/create.
        org_id (str): The organization ID.
        retention_seconds (int): Retention period in seconds.

    Returns:
        bool: True if the bucket exists or was created successfully, False otherwise.
    """
    try:
        buckets_api = client.buckets_api()
        existing_bucket = buckets_api.find_bucket_by_name(bucket_name)
        if existing_bucket:
            logger.info(f"âœ… Bucket '{bucket_name}' already exists.")
            return True
        else:
            # Create the bucket
            new_bucket = buckets_api.create_bucket(
                org_id=org_id,
                name=bucket_name,
                retention_rules=[{"type": "expire", "everySeconds": retention_seconds}]
            )
            logger.info(f"âœ… Bucket '{bucket_name}' created with retention period of {retention_seconds} seconds.")
            return True
    except Exception as e:
        logger.error(f"âŒ Failed to ensure bucket '{bucket_name}' exists: {e}")
        return False

def write_test_points(client: InfluxDBClient, bucket: str, num_points: int):
    """
    Writes multiple test data points with random values to InfluxDB.

    Args:
        client (InfluxDBClient): The InfluxDB client instance.
        bucket (str): The name of the bucket to write data to.
        num_points (int): Number of test data points to write.

    Returns:
        list: A list of dictionaries containing measurement, tags, fields, and timestamp for each point.
    """
    write_api = client.write_api(write_options=SYNCHRONOUS)
    measurement = "network_performance"

    # Base timestamp
    base_time = datetime.utcnow().replace(tzinfo=timezone.utc)

    test_points_info = []

    for i in range(num_points):
        # Increment timestamp by 30 seconds for each point
        current_time = base_time + timedelta(seconds=30 * i)
        timestamp_ns = datetime_to_epoch_ns(current_time)

        # Define tags
        tags = {
            "ai_sensor_name": f"vstream:if{i%5}",  # Example variation
            "ai_sensor_ip_address": f"192.168.30.{142 + i%10}",
            "ai_sensor_interface_number": f"{3 + i%3}",
            "application_group": "WEB",
            "traffic_direction": random.choice(["inbound", "outbound", "unknown"]),
            "application_protocol": random.choice(["HTTP", "HTTPS", "unknown"]),
            "application_name": "HTTPS",
            "server_host_ip_address": f"52.119.41.{58 + i%10}",
            "client_host_ip_address": f"192.168.30.{111 + i%10}",
            "server_port": "443"
        }

        # Generate random fields
        fields = generate_random_field_values()

        # Create the point
        point = Point(measurement)
        for tag_key, tag_value in tags.items():
            point = point.tag(tag_key, tag_value)
        for field_key, field_value in fields.items():
            point = point.field(field_key, field_value)
        point = point.time(timestamp_ns, WritePrecision.NS)

        try:
            # Write the point to InfluxDB
            write_api.write(bucket=bucket, org=INFLUX_ORG_ID, record=point)
            logger.info(f"âœ… Wrote point {i+1}/{num_points} to InfluxDB at {current_time.isoformat()} (ns: {timestamp_ns}).")
            
            # Log the exact data sent
            log_entry = {
                "measurement": measurement,
                "tags": tags,
                "fields": fields,
                "timestamp_ns": timestamp_ns
            }
            logger.debug(f"Data sent to InfluxDB: {log_entry}")
        except Exception as e:
            logger.error(f"âŒ Failed to write point {i+1}: {e}")
            continue

        # Store point info for potential further use
        test_points_info.append({
            "measurement": measurement,
            "tags": tags,
            "fields": fields,
            "timestamp_ns": timestamp_ns
        })

    return test_points_info

def query_field_statistics(client: InfluxDBClient, bucket: str, measurement: str, field: str):
    """
    Queries statistics (mean, min, max, sum) for a specific field.

    Args:
        client (InfluxDBClient): The InfluxDB client instance.
        bucket (str): The name of the bucket to query data from.
        measurement (str): The measurement name.
        field (str): The field name to compute statistics for.

    Returns:
        dict: A dictionary containing the computed statistics.
    """
    query_api = client.query_api()

    # Construct Flux query to compute statistics
    flux_query = f'''
    from(bucket: "{bucket}")
      |> range(start: -12h)  // Adjust the range as needed
      |> filter(fn: (r) => r["_measurement"] == "{measurement}")
      |> filter(fn: (r) => r["_field"] == "{field}")
      |> keep(columns: ["_value"])
      |> yield(name: "raw")
    '''

    try:
        result = query_api.query(flux_query, org=INFLUX_ORG_ID)

        values = []
        for table in result:
            for record in table.records:
                values.append(record.get_value())

        if not values:
            logger.warning(f"âŒ No data found for field '{field}'.")
            return {}

        statistics = {
            "count": len(values),
            "mean": sum(values) / len(values),
            "min": min(values),
            "max": max(values),
            "sum": sum(values)
        }

        logger.info(f"ðŸ“Š Statistics for field '{field}': {statistics}")
        return statistics

    except Exception as e:
        logger.error(f"âŒ Failed to query statistics for field '{field}': {e}")
        return {}

def retrieve_all_field_statistics(client: InfluxDBClient, bucket: str, measurement: str, fields: list):
    """
    Retrieves statistics for all specified fields.

    Args:
        client (InfluxDBClient): The InfluxDB client instance.
        bucket (str): The name of the bucket to query data from.
        measurement (str): The measurement name.
        fields (list): A list of field names to compute statistics for.

    Returns:
        dict: A dictionary containing statistics for each field.
    """
    all_statistics = {}
    for field in fields:
        stats = query_field_statistics(client, bucket, measurement, field)
        if stats:
            all_statistics[field] = stats
    return all_statistics

# === Main Execution ===

def main():
    # Construct the InfluxDB URL
    influx_url = f"http://{INFLUX_HOST}:{INFLUX_PORT}"
    
    logger.info(f"ðŸ”— Connecting to InfluxDB at {influx_url}...")
    
    try:
        # Initialize the InfluxDB client
        client = InfluxDBClient(
            url=influx_url,
            token=INFLUX_TOKEN,
            org=INFLUX_ORG_ID
        )
    except Exception as e:
        logger.error(f"âŒ Failed to create InfluxDB client: {e}")
        sys.exit(1)
    
    # Ensure the bucket exists
    logger.info(f"ðŸ” Checking if bucket '{INFLUX_BUCKET}' exists...")
    if not ensure_bucket_exists(client, INFLUX_BUCKET, INFLUX_ORG_ID, RETENTION_SECONDS):
        logger.error("âŒ Unable to ensure bucket exists. Exiting.")
        client.close()
        sys.exit(1)
    
    # Write multiple test points with random values
    logger.info(f"ðŸ“ Writing {NUM_TEST_POINTS} test points with random values to InfluxDB...")
    test_points_info = write_test_points(client, INFLUX_BUCKET, NUM_TEST_POINTS)
    
    # Allow some time for data to be ingested
    logger.info("â³ Waiting for data ingestion...")
    time.sleep(5)
    
    # Define measurement and fields
    if not test_points_info:
        logger.error("âŒ No test points were written. Exiting.")
        client.close()
        sys.exit(1)
    
    measurement = test_points_info[0]["measurement"]
    
    # Retrieve and print statistics for all fields
    logger.info("ðŸ“ˆ Retrieving statistics for all specified fields...")
    field_statistics = retrieve_all_field_statistics(client, INFLUX_BUCKET, measurement, FIELDS_TO_TEST)
    
    if field_statistics:
        logger.info("\nðŸ“Š Field Statistics Summary:")
        for field, stats in field_statistics.items():
            logger.info(f"- {field}:")
            for stat_key, stat_value in stats.items():
                logger.info(f"  â€¢ {stat_key}: {stat_value}")
    else:
        logger.warning("âŒ No statistics were retrieved.")
    
    # Close the InfluxDB client
    client.close()

if __name__ == "__main__":
    main()
