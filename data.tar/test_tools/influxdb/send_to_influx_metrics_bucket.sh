#!/bin/bash

# Configuration
INFLUXDB_URL="http://localhost:8086"
BUCKET="metrics"
ORG="Netscout"  # Organization name for InfluxDB
TOKEN="MyInfluxToken123"

# Data payload template (line protocol format)
# Example: measurement,tag1=value1,tag2=value2 field1=value1 timestamp
MEASUREMENT="cpu_load_short"
HOST="server01"
REGION="us-west"

# Loop and send data every 5 seconds
echo "Starting data loop. Sending data to InfluxDB bucket '$BUCKET' for organization '$ORG' every 5 seconds..."
while true; do
  # Generate a true timestamp in nanoseconds
  TIMESTAMP=$(date +%s%N)

  # Construct line protocol data
  DATA="$MEASUREMENT,host=$HOST,region=$REGION value=1 $TIMESTAMP"

  # Send data to InfluxDB
  response=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$INFLUXDB_URL/api/v2/write?bucket=$BUCKET&org=$ORG&precision=ns" \
    --header "Authorization: Token $TOKEN" \
    --header "Content-Type: text/plain; charset=utf-8" \
    --data-binary "$DATA")

  # Check response
  if [ "$response" -eq 204 ]; then
    echo "[$(date)] Data sent: $DATA"
  else
    echo "[$(date)] Failed to send data. HTTP response code: $response"
  fi

  # Wait 5 seconds before sending the next data point
  sleep 5
done
