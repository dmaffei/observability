#!/bin/bash

# Function to extract IP address of interfaces starting with "ens"
extract_ens_ip() {
    local output_file="ip_address.env"

    # Extract the IP address
    local ip_address=$(ip a | awk '
    BEGIN {
        iface = ""
        ip = ""
    }
    {
        # Match lines with interface names starting with "ens"
        if ($2 ~ /^ens/) {
            iface = $2
            # Remove trailing colon from interface name
            sub(/:/, "", iface)
        }
        # Match lines with IPv4 addresses
        if ($1 == "inet" && iface != "") {
            ip = $2
            # Extract only the IP address without the CIDR
            split(ip, arr, "/")
            print arr[1]
            exit
        }
    }')

    # Check if an IP address was found
    if [[ -n $ip_address ]]; then
        # Check if the file already contains this IP address
        if grep -q "IP_ADDRESS=$ip_address" "$output_file" 2>/dev/null; then
            echo "IP address $ip_address is already in $output_file"
        else
            echo "IP_ADDRESS=$ip_address" >> "$output_file"
            echo "IP address appended to $output_file"
        fi
    else
        echo "No IP address found for interfaces starting with 'ens'"
        return 1
    fi
}

# Call the function
extract_ens_ip
