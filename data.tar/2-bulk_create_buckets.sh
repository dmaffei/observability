#!/bin/bash
source .env

# Log file
LOG_FILE="initialize_influxdbV2.log"
exec > >(tee -a "$LOG_FILE") 2>&1

ADMIN_USERNAME="${DEFAULT_ADMIN}"   # Optional but recommended: use curly braces
ADMIN_PASSWORD="${DEFAULT_PASSWORD}"
ADMIN_TOKEN=$(cat "$COMPOSE_PATH/secrets/influxdb_admin_token")
ORG_NAME="${DEFAULT_ORG}"
RETENTION_POLICY="30d"
IP_ADDRESS="${IP_ADDRESS}"
INFLUXDB_HOST="http://$IP_ADDRESS:8086"

# List of buckets, descriptions, tags, and locations
BUCKETS=(
  "metrics::Metrics bucket::env=prod,team=metrics,location=HQ"
  "logs::Logs bucket::env=prod,team=logging,location=HQ"
  "events::Events bucket::env=prod,team=events,location=HQ"
  "telegraf_OMNIS.netops::NetOps bucket::env=lab,team=omnis,location=SJ_Lab"
  "telegraf_OMNIS.performance::Performance bucket::env=lab,team=omnis,location=SJ_Lab"
  "telegraf_OMNIS.asset::Asset bucket::env=lab,team=omnis,location=SJ_Lab"
  "telegraf_dockers::Telegraf Docker metrics::env=lab,team=dockers,location=SJ_Lab"
  "telegraf_vmware::VMware metrics bucket::env=prod,team=vmware,location=SJ_Lab"
)

# Log start time
echo -e "\n----- Starting InfluxDB Initialization: $(date) -----\n"

# Function to check if a bucket exists
check_bucket_exists() {
  local bucket_name="$1"
  curl -s -X GET "$INFLUXDB_HOST/api/v2/buckets?name=$bucket_name" \
    -H "Authorization: Token $ADMIN_TOKEN" | jq -e '.buckets | length > 0' >/dev/null
}

# Function to create a label (tag) with a specific color
create_label() {
  local label_name="$1"
  local label_properties="$2"
  local label_color="$3"

  echo -e "\nCreating label: $label_name with properties: $label_properties and color: $label_color"
  curl -s -X POST "$INFLUXDB_HOST/api/v2/labels" \
    -H "Authorization: Token $ADMIN_TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
      \"name\": \"$label_name\",
      \"orgID\": \"$(curl -s -X GET "$INFLUXDB_HOST/api/v2/orgs?org=$ORG_NAME" -H "Authorization: Token $ADMIN_TOKEN" | jq -r '.orgs[0].id')\",
      \"properties\": {
        \"color\": \"$label_color\",
        \"description\": \"$label_properties\"
      }
    }" >/dev/null
}

# Function to associate a label with a bucket
associate_label_with_bucket() {
  local bucket_name="$1"
  local label_name="$2"

  bucket_id=$(curl -s -X GET "$INFLUXDB_HOST/api/v2/buckets?name=$bucket_name" \
    -H "Authorization: Token $ADMIN_TOKEN" | jq -r '.buckets[0].id')
  label_id=$(curl -s -X GET "$INFLUXDB_HOST/api/v2/labels?name=$label_name" \
    -H "Authorization: Token $ADMIN_TOKEN" | jq -r '.labels[0].id')

  if [[ -n "$bucket_id" && -n "$label_id" ]]; then
    echo -e "\nAssociating label $label_name with bucket $bucket_name"
    curl -s -X POST "$INFLUXDB_HOST/api/v2/buckets/$bucket_id/labels" \
      -H "Authorization: Token $ADMIN_TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"labelID\": \"$label_id\"}" >/dev/null
    echo "Label $label_name associated successfully with bucket $bucket_name."
  else
    echo "Failed to associate label $label_name with bucket $bucket_name. Bucket or label ID not found."
  fi
}

# Create buckets and associate labels
for BUCKET_INFO in "${BUCKETS[@]}"; do
  BUCKET_NAME=$(echo "$BUCKET_INFO" | awk -F "::" '{print $1}')
  BUCKET_DESCRIPTION=$(echo "$BUCKET_INFO" | awk -F "::" '{print $2}')
  BUCKET_TAGS=$(echo "$BUCKET_INFO" | awk -F "::" '{print $3}')

  echo -e "\nProcessing bucket: $BUCKET_NAME, Description: $BUCKET_DESCRIPTION, Tags: $BUCKET_TAGS"

  if check_bucket_exists "$BUCKET_NAME"; then
    echo "Bucket $BUCKET_NAME already exists."
  else
    echo -e "\nCreating bucket: $BUCKET_NAME with retention policy: $RETENTION_POLICY"
    docker exec -it influxdb influx bucket create \
      --name "$BUCKET_NAME" \
      --org "$ORG_NAME" \
      --retention "$RETENTION_POLICY" \
      --description "$BUCKET_DESCRIPTION" \
      --token "$ADMIN_TOKEN"
  fi

  IFS=',' read -ra TAGS <<< "$BUCKET_TAGS"
  for TAG in "${TAGS[@]}"; do
    TAG_KEY=$(echo "$TAG" | cut -d '=' -f 1)
    TAG_VALUE=$(echo "$TAG" | cut -d '=' -f 2)
    LABEL_NAME="${TAG_KEY}_${TAG_VALUE}"
    LABEL_DESCRIPTION="${TAG_KEY}: ${TAG_VALUE}"

    case "$TAG_KEY" in
      "env")
        [[ "$TAG_VALUE" == "prod" ]] && COLOR="#238449"
        [[ "$TAG_VALUE" == "dev" ]] && COLOR="#e74c3c"
        [[ "$TAG_VALUE" == "lab" ]] && COLOR="#f7dc6f"
        ;;
      "team")
        case "$TAG_VALUE" in
          "core") COLOR="#5c10a0" ;;
          "metrics") COLOR="#BEF0FF" ;;
          "events") COLOR="#E85B1C" ;;
          "logging") COLOR="#9bf445" ;;
          "omnis") COLOR="#34bb55" ;;
          "docker") COLOR="#434453" ;;
          "windows") COLOR="#00a3ff" ;;
          "vmware") COLOR="#FFD255" ;;
          "proxmox") COLOR="#BF3D5E" ;;
        esac
        ;;
      "location")
        COLOR="#cccccc"  # Default gray for location tags
        ;;
    esac

    create_label "$LABEL_NAME" "$LABEL_DESCRIPTION" "$COLOR"
    associate_label_with_bucket "$BUCKET_NAME" "$LABEL_NAME"
  done
done

echo -e "\nAll buckets processed successfully with labels (tags) updates."
echo -e "----- InfluxDB Initialization Completed: $(date) -----\n"
