#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

# InfluxDB image to target
INFLUXDB_IMAGE="influxdb:latest"  # Replace with your specific InfluxDB image tag if different

echo -e "${BLUE}Stopping and removing all containers, images, and volumes related to $INFLUXDB_IMAGE...${NC}"

# Stop and remove all containers using the InfluxDB image
containers=$(docker ps -aq --filter "ancestor=$INFLUXDB_IMAGE")
if [ -n "$containers" ]; then
  echo -e "${BLUE}Stopping containers...${NC}"
  docker stop $containers && docker rm $containers
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}Stopped and removed containers:${NC} $containers"
  else
    echo -e "${RED}Failed to stop or remove some containers.${NC}"
  fi
else
  echo -e "${GREEN}No running containers found for $INFLUXDB_IMAGE.${NC}"
fi

# Find and remove any InfluxDB-specific containers by name pattern
echo -e "${BLUE}Searching for containers with 'influxdb' in their name...${NC}"
influxdb_containers=$(docker ps -aq --filter "name=influxdb")
if [ -n "$influxdb_containers" ]; then
  echo -e "${BLUE}Stopping and removing containers with 'influxdb' in their name...${NC}"
  docker stop $influxdb_containers && docker rm $influxdb_containers
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}Stopped and removed containers:${NC} $influxdb_containers"
  else
    echo -e "${RED}Failed to stop or remove some containers by name.${NC}"
  fi
else
  echo -e "${GREEN}No containers with 'influxdb' in their name found.${NC}"
fi

# Remove the InfluxDB image
image=$(docker images -q $INFLUXDB_IMAGE)
if [ -n "$image" ]; then
  echo -e "${BLUE}Removing InfluxDB image...${NC}"
  docker rmi -f $image
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}Removed image:${NC} $image"
  else
    echo -e "${RED}Failed to remove image $INFLUXDB_IMAGE.${NC}"
  fi
else
  echo -e "${GREEN}No image found for $INFLUXDB_IMAGE.${NC}"
fi

# Remove orphaned volumes
echo -e "${BLUE}Removing orphaned volumes...${NC}"
docker volume prune -f
if [ $? -eq 0 ]; then
  echo -e "${GREEN}Orphaned volumes removed.${NC}"
else
  echo -e "${RED}Failed to remove some volumes.${NC}"
fi

# Remove any volumes related to InfluxDB
echo -e "${BLUE}Removing volumes related to InfluxDB...${NC}"
influxdb_volumes=$(docker volume ls -q | grep influxdb)
if [ -n "$influxdb_volumes" ]; then
  docker volume rm $influxdb_volumes
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}Removed volumes:${NC} $influxdb_volumes"
  else
    echo -e "${RED}Failed to remove some InfluxDB-specific volumes.${NC}"
  fi
else
  echo -e "${GREEN}No volumes related to InfluxDB found.${NC}"
fi

echo -e "${GREEN}Cleanup completed.${NC}"
