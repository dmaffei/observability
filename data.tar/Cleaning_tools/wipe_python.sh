#!/bin/bash

# Strict mode
set -euo pipefail

# Color codes for logging
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Logging functions
log_info() {
    echo -e "${YELLOW}[INFO] $*${NC}"
}

log_success() {
    echo -e "${GREEN}[SUCCESS] $*${NC}"
}

log_error() {
    echo -e "${RED}[ERROR] $*${NC}" >&2
}

# Function to check for root privileges
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root or with sudo privileges."
        exit 1
    fi
}

# Function to remove Python and pip
remove_python_and_pip() {
    log_info "Identifying Python installations..."

    # Remove Python packages based on the package manager
    if command -v dnf &> /dev/null; then
        package_manager="dnf"
    elif command -v yum &> /dev/null; then
        package_manager="yum"
    elif command -v apt &> /dev/null; then
        package_manager="apt"
    else
        log_error "Unsupported package manager. Cannot proceed."
        exit 1
    fi

    # Remove system-installed Python and pip
    log_info "Removing system-installed Python and pip..."
    case $package_manager in
        dnf|yum)
            $package_manager remove -y python3 python3-pip python3-virtualenv
            ;;
        apt)
            apt remove -y python3 python3-pip python3-venv
            apt autoremove -y
            ;;
    esac

    # Remove manually installed Python versions
    log_info "Searching for manually installed Python versions..."
    for py_dir in /usr/local/bin/python* /usr/local/lib/python* /usr/bin/python* /opt/python*; do
        if [[ -e "$py_dir" ]]; then
            log_info "Removing $py_dir"
            rm -rf "$py_dir"
        fi
    done

    # Remove pip cache and user-installed packages
    log_info "Removing pip cache and user-installed packages..."
    rm -rf ~/.local/lib/python* ~/.cache/pip

    # Check for any Python binaries in PATH and remove them
    log_info "Scanning for remaining Python binaries in PATH..."
    for binary in $(which -a python3 pip3 2>/dev/null || true); do
        if [[ -x "$binary" ]]; then
            log_info "Removing $binary"
            rm -f "$binary"
        fi
    done

    log_success "Python and pip have been completely removed from the system."
}

# Main function
main() {
    check_root
    remove_python_and_pip
}

# Execute the script
main
