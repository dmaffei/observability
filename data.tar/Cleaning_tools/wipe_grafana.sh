#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

# Grafana image to target
GRAFANA_IMAGE="grafana/grafana-oss:main-ubuntu"

echo -e "${BLUE}Stopping and removing all containers, images, and volumes related to $GRAFANA_IMAGE...${NC}"

# Stop and remove all containers using the Grafana image
containers=$(docker ps -aq --filter "ancestor=$GRAFANA_IMAGE")
if [ -n "$containers" ]; then
  echo -e "${BLUE}Stopping containers...${NC}"
  docker stop $containers && docker rm $containers
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}Stopped and removed containers:${NC} $containers"
  else
    echo -e "${RED}Failed to stop or remove some containers.${NC}"
  fi
else
  echo -e "${GREEN}No running containers found for $GRAFANA_IMAGE.${NC}"
fi

# Remove the Grafana image
image=$(docker images -q $GRAFANA_IMAGE)
if [ -n "$image" ]; then
  echo -e "${BLUE}Removing Grafana image...${NC}"
  docker rmi -f $image
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}Removed image:${NC} $image"
  else
    echo -e "${RED}Failed to remove image $GRAFANA_IMAGE.${NC}"
  fi
else
  echo -e "${GREEN}No image found for $GRAFANA_IMAGE.${NC}"
fi

# Remove orphaned volumes
echo -e "${BLUE}Removing orphaned volumes...${NC}"
docker volume prune -f
if [ $? -eq 0 ]; then
  echo -e "${GREEN}Orphaned volumes removed.${NC}"
else
  echo -e "${RED}Failed to remove some volumes.${NC}"
fi

echo -e "${GREEN}Cleanup completed.${NC}"
