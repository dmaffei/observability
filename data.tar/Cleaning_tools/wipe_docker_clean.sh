#!/bin/bash

# ========================================================================
# Docker Cleanup Script
# This script removes all Docker containers, images, and volumes.
# WARNING: This will delete ALL Docker containers, images, and volumes!
# ========================================================================

# Function to prompt for confirmation
confirm() {
    read -r -p "Are you sure you want to remove ALL Docker containers, images, and volumes? [y/N] " response
    case "$response" in
        [yY][eE][sS]|[yY])
            return 0
            ;;
        *)
            echo "Operation canceled."
            exit 1
            ;;
    esac
}

# Stop and remove all Docker containers
remove_containers() {
    echo "Stopping and removing all Docker containers..."
    docker container stop $(docker container ls -aq) 2>/dev/null
    docker container rm $(docker container ls -aq) 2>/dev/null
}

# Remove all Docker images
remove_images() {
    echo "Removing all Docker images..."
    docker image rm $(docker image ls -aq) 2>/dev/null
}

# Remove all Docker volumes
remove_volumes() {
    echo "Removing all Docker volumes..."
    docker volume rm $(docker volume ls -q) 2>/dev/null
}

# Remove all Docker networks (except default bridge network)
remove_networks() {
    echo "Removing all Docker networks (except default bridge)..."
    docker network prune -f
}

# Main execution flow
main() {
    confirm
    remove_containers
    remove_images
    remove_volumes
    remove_networks
    echo "Docker cleanup completed successfully."
}

main
