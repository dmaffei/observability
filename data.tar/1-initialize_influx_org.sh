
#!/bin/bash
source .env
echo $COMPOSE_PATH
# Log file
LOG_FILE="initialize_influxdbV2.log"
exec > >(tee -a "$LOG_FILE") 2>&1

# Load secrets and configurations
ADMIN_USERNAME=$(cat "$COMPOSE_PATH/secrets/influxdb_admin_username")
ADMIN_PASSWORD=$(cat "$COMPOSE_PATH/secrets/influxdb_admin_password")
ADMIN_TOKEN=$(cat "$COMPOSE_PATH/secrets/influxdb_admin_token")
ORG_NAME=$(cat "$COMPOSE_PATH/secrets/influxdb_org_name")
RETENTION_POLICY="30d"
IP_ADDRESS="$IP_ADDRESS"

# List of buckets to create
BUCKETS=(
  "default"
)

# Log start time
echo "----- Starting InfluxDB Initialization: $(date) -----"

# Setup InfluxDB with the default bucket
echo "Initializing InfluxDB setup..."
docker exec -it influxdb influx setup --skip-verify \
  --username "$ADMIN_USERNAME" \
  --password "$ADMIN_PASSWORD" \
  --token "$ADMIN_TOKEN" \
  --org "$ORG_NAME" \
  --bucket "default" \
  --retention "$RETENTION_POLICY" \
  --force

# Verify InfluxDB setup status
SETUP_STATUS=$(curl -s -X GET "http://$IP_ADDRESS:8086/api/v2/setup" | jq -r '.allowed')
if [[ "$SETUP_STATUS" != "false" ]]; then
  echo "InfluxDB setup completed successfully."
else
  echo ""
fi

# Create additional buckets with a 30-day retention policy
echo "Creating default buckets..."
for BUCKET in "${BUCKETS[@]}"; do
  if [[ "$BUCKET" != "default" ]]; then
    echo "Creating bucket: $BUCKET with retention policy: $RETENTION_POLICY"
    docker exec -it influxdb influx bucket create \
      --name "$BUCKET" \
      --org "$ORG_NAME" \
      --retention "$RETENTION_POLICY" \
      --token "$ADMIN_TOKEN"
  fi
done

echo ""
echo "----- InfluxDB Initialization Completed: $(date) -----"
