#!/bin/bash
source .env

# Set Grafana URL and Secret Paths

#IP_ADDRESS="${IP_ADDRESS}"
GRAFANA_URL="http://$IP_ADDRESS:3000"

GRAFANA_USER="${DEFAULT_ADMIN}"   
GRAFANA_PASSWORD="${DEFAULT_PASSWORD}"
TOKEN_OUTPUT_FILE="${COMPOSE_PATH}/secrets/grafana_service_token"

# Step 1: Create a Service Account
echo "Creating Grafana service account..."
SERVICE_ACCOUNT_RESPONSE=$(curl -s -X POST "${GRAFANA_URL}/api/serviceaccounts" \
  -u "${GRAFANA_USER}:${GRAFANA_PASSWORD}" \
  -H "Content-Type: application/json" \
  -d '{
        "name": "all-access-service",
        "role": "Admin"
      }')

# Extract the service account ID
SERVICE_ACCOUNT_ID=$(echo "$SERVICE_ACCOUNT_RESPONSE" | jq -r '.id')

if [[ -z "$SERVICE_ACCOUNT_ID" || "$SERVICE_ACCOUNT_ID" == "null" ]]; then
  echo "Error: Failed to create Grafana service account. Response: $SERVICE_ACCOUNT_RESPONSE"
  exit 1
fi

echo ""

# Step 2: Create an API Token for the Service Account
echo "Creating API..."
TOKEN_RESPONSE=$(curl -s -X POST "${GRAFANA_URL}/api/serviceaccounts/${SERVICE_ACCOUNT_ID}/tokens" \
  -u "${GRAFANA_USER}:${GRAFANA_PASSWORD}" \
  -H "Content-Type: application/json" \
  -d '{
        "name": "all-access-token",
        "role": "Admin",
        "secondsToLive": 31536000
      }')

# Extract the token
SERVICE_TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r '.key')

if [[ -z "$SERVICE_TOKEN" || "$SERVICE_TOKEN" == "null" ]]; then
  echo "Error: Failed to create API token. Response: $TOKEN_RESPONSE"
  exit 1
fi

# Step 3: Save the Token to a Secret File
echo "$SERVICE_TOKEN" > "$TOKEN_OUTPUT_FILE"
chmod 600 "$TOKEN_OUTPUT_FILE"
echo ""

# Display the token (optional)
echo "Service API Token: $SERVICE_TOKEN"
echo "Token creation process completed."

