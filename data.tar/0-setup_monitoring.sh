#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
NC='\033[0m'

# Log file
LOG_FILE="./deployment.log"
> "$LOG_FILE" # Clear previous log file

# ================================
# Configuration Variables
# ================================
INSTALL_PATH="/home/installer/Projects"
COMPOSE_PATH="$INSTALL_PATH/grafana-monitoring"
DEFAULT_ADMIN="admin"
DEFAULT_PASSWORD="netscout1"
DEFAULT_ORG="Netscout"
INFLUXDB_BUCKETS=("telegraf_OMNIS.performance" "telegraf_OMNIS.asset" "telegraf_OMNIS.netops")
IP_ADDRESS=${1:-""}
DOCKER_GID=$(getent group docker | cut -d: -f3)
echo -e "${GREEN}Docker group ID (GID) is: $DOCKER_GID${NC}"
GRAFANA_SERVICE_TOKEN=""
INFLUXDB_ORG_ID=""
INFLUX_TOKEN="MyInfluxToken123"

# ================================
# Directory Tree 
# ================================

mkdir -p "$COMPOSE_PATH"
mkdir -p "$COMPOSE_PATH/grafana"
mkdir -p "$COMPOSE_PATH/grafana/provisioning"
mkdir -p "$COMPOSE_PATH/grafana/provisioning/datasources"
mkdir -p "$COMPOSE_PATH/influxdb"
mkdir -p "$COMPOSE_PATH/prometheus"
mkdir -p "$COMPOSE_PATH/prometheus/config"
mkdir -p "$COMPOSE_PATH/portainer"
mkdir -p "$COMPOSE_PATH/data/mongodb"
mkdir -p "$COMPOSE_PATH/data/mongodb-config"
mkdir -p "$COMPOSE_PATH/dbgate/connections"
mkdir -p "$COMPOSE_PATH/dbgate/data"
mkdir -p "$COMPOSE_PATH/dbgate/persistance"

# ================================
# Helper Functions
# ================================
log() {
    local message=$1
    echo -e "$message" | tee -a "$LOG_FILE"
}

step_start() {
    local step=$1
    echo -e "${CYAN}STARTING: $step...${NC}" | tee -a "$LOG_FILE"
}

step_pass() {
    local step=$1
    echo -e "${GREEN}PASS: $step${NC}" | tee -a "$LOG_FILE"
}

step_fail() {
    local step=$1
    echo -e "${RED}FAIL: $step. Check $LOG_FILE for details.${NC}" | tee -a "$LOG_FILE"
    exit 1
}

# ================================
# Functions
# ================================



select_ip_address() {
    step_start "IP Address Selection"
    mapfile -t ip_addresses < <(ip -o -4 addr list | grep -v " lo\| docker" | awk '{print $4}' | cut -d/ -f1)
    if [ ${#ip_addresses[@]} -eq 0 ]; then
        step_fail "${RED}No active network interfaces found"
    fi

    echo -e "${CYAN}Please select the IP address to bind services to:${NC}"
    select ip in "${ip_addresses[@]}"; do
        if [[ -n "$ip" ]]; then
            IP_ADDRESS="$ip"
            log "Selected IP Address: $IP_ADDRESS"
            step_pass "IP Address Selection"
            break
        else
            echo -e "${RED}Invalid selection. Try again.${NC}" | tee -a "$LOG_FILE"
        fi
    done
}

create_secrets() {
    step_start "Secrets Creation"
    local secrets_dir="$COMPOSE_PATH/secrets"
    mkdir -p "$secrets_dir"

    echo "$DEFAULT_ADMIN" > "$secrets_dir/grafana_admin_user"
    echo "$DEFAULT_PASSWORD" > "$secrets_dir/grafana_admin_password"
    echo "$GRAFANA_SERVICE_TOKEN" > "$secrets_dir/grafana_service_token"
    echo "$DEFAULT_ADMIN" > "$secrets_dir/influxdb_admin_username"
    echo "$DEFAULT_PASSWORD" > "$secrets_dir/influxdb_admin_password"
    #echo "$INFLUXDB_ORG_ID" > "$secrets_dir/influxdb_org_id"
    echo "$DEFAULT_ORG" > "$secrets_dir/influxdb_org_name"
    echo "$INFLUX_TOKEN" > "$secrets_dir/influxdb_admin_token"

    for bucket in "${INFLUXDB_BUCKETS[@]}"; do
        echo "$bucket" > "$secrets_dir/influxdb-bucket-${bucket}"
    done

    log "Secrets created in $secrets_dir"
    step_pass "Secrets Creation"
}

create_env_file() {
    step_start "Environment File Creation"
    cat > "$COMPOSE_PATH/.env" << EOF
IP_ADDRESS=$IP_ADDRESS
DEFAULT_ADMIN=$DEFAULT_ADMIN
DEFAULT_PASSWORD=$DEFAULT_PASSWORD
DEFAULT_ORG=$DEFAULT_ORG
INSTALL_PATH=$INSTALL_PATH
COMPOSE_PATH=$COMPOSE_PATH
EOF

    if [ $? -eq 0 ]; then
        log ".env file created at $COMPOSE_PATH/.env"
        step_pass "Environment File Creation"
        cp -f $COMPOSE_PATH/.env /home/installer/InstallKit/.env
    else
        step_fail "${RED}Environment File Creation"
    fi
}


create_telegraf_conf() {
    step_start "Telegraf Configuration File Creation"
    local telegraf_dir="$COMPOSE_PATH/telegraf/kafka"
    local telegraf_file="$telegraf_dir/telegraf.conf"

    # Create the parent directory
    mkdir -p "$telegraf_dir"

    # Write the configuration file
    cat > "$telegraf_file" << EOF

# Configuration for telegraf agent
[agent]
  interval = "10s"
  round_interval = true
  metric_batch_size = 1000
  metric_buffer_limit = 10000
  collection_jitter = "0s"
  flush_interval = "10s"
  flush_jitter = "0s"
  precision = ""
  hostname = ""
  omit_hostname = false

# Docker input plugin configuration
[[inputs.docker]]
  endpoint = "unix:///var/run/docker.sock"
  gather_services = false
  container_names = []
  source_tag = false
  container_name_include = []
  container_name_exclude = []
  timeout = "5s"
  perdevice = true
  total = false
  docker_label_include = []
  docker_label_exclude = []
  tag_env = ["JAVA_HOME", "HEAP_SIZE"]

#telegraf.conf config file with kafka with no security - multiple topics upload to influxdb
# InfluxDB output for OMNIS.netops
[[outputs.influxdb_v2]]
  urls = ["http://$IP_ADDRESS:8086"]
  token = "$INFLUX_TOKEN"
  #token = "MyInfluxToken123"
  organization = "$DEFAULT_ORG"
  bucket = "telegraf_OMNIS.netops"
  ## Only write data with topic tag "OMNIS.netops"
  [outputs.influxdb_v2.tagpass]
    topic = ["OMNIS.netops"]

# InfluxDB output for OMNIS.performance
[[outputs.influxdb_v2]]
  urls = ["http://$IP_ADDRESS:8086"]
  token = "$INFLUX_TOKEN"
  #token = "MyInfluxToken123"
  organization = "$DEFAULT_ORG"
  bucket = "telegraf_OMNIS.performance"
  ## Only write data with topic tag "OMNIS.performance"
  [outputs.influxdb_v2.tagpass]
    topic = ["OMNIS.performance"]

# InfluxDB output for OMNIS.asset
[[outputs.influxdb_v2]]
  urls = ["http://$IP_ADDRESS:8086"]
  token = "$INFLUX_TOKEN"
  #token = "MyInfluxToken123"
  organization = "$DEFAULT_ORG"
  bucket = "telegraf_OMNIS.asset"
  ## Only write data with topic tag "OMNIS.asset"
  [outputs.influxdb_v2.tagpass]
    topic = ["OMNIS.asset"]

# Kafka consumer for OMNIS.netops
[[inputs.kafka_consumer]]
  brokers = ["$IP_ADDRESS:9092"]
  topics = ["OMNIS.netops"]
  data_format = "json"
  json_time_key = "timestamp"
  json_time_format = "2006-01-02 15:04:05.000000 UTC"
  json_timezone = "UTC"
  tag_keys = [
    "server_host_ip_address",
    "client_host_ip_address",
    "application_name",
    "application_group",
    "traffic_direction",
    "application_protocol",
    "ai_sensor_ip_address",
    "ai_sensor_name"
  ]
  json_string_fields = [
    "message_name", 
    "response_code", 
    "response_description", 
    "client_site", 
    "server_site", 
    "client_community", 
    "server_community"
  ]
  ## Add a unique topic tag for filtering
  [inputs.kafka_consumer.tags]
    topic = "OMNIS.netops"

# Kafka consumer for OMNIS.performance
[[inputs.kafka_consumer]]
  brokers = ["$IP_ADDRESS:9092"]
  topics = ["OMNIS.performance"]
  data_format = "json"
  json_time_key = "timestamp"
  json_time_format = "2006-01-02 15:04:05.000000 UTC"
  json_timezone = "UTC"
  tag_keys = [
    "server_host_ip_address",
    "client_host_ip_address",
    "application_name",
    "application_group",
    "ai_sensor_ip_address",
    "ai_sensor_name"
  ]
  json_string_fields = [
    "message_name", 
    "response_code", 
    "response_description", 
    "transaction_status"
  ]
  ## Add a unique topic tag for filtering
  [inputs.kafka_consumer.tags]
    topic = "OMNIS.performance"

# Kafka consumer for OMNIS.asset
[[inputs.kafka_consumer]]
  brokers = ["$IP_ADDRESS:9092"]
  topics = ["OMNIS.asset"]
  data_format = "json"
  json_time_key = "timestamp"
  json_time_format = "2006-01-02 15:04:05.000000 UTC"
  json_timezone = "UTC"
  tag_keys = [
    "server_host_ip_address",
    "client_host_ip_address",
    "application_name",
    "application_group",
    "ai_sensor_ip_address",
    "ai_sensor_name"
  ]
  json_string_fields = [
    "message_name", 
    "transaction_status", 
    "response_code", 
    "response_description"
  ]
  ## Add a unique topic tag for filtering
  [inputs.kafka_consumer.tags]
    topic = "OMNIS.asset"

  # No additional configuration
EOF

     # Validate the file creation
    if [ -f "$telegraf_file" ]; then
        log "Telegraf configuration created at $telegraf_file"
        step_pass "Telegraf Configuration File Creation"
    else
        step_fail "${RED}Telegraf Configuration File Creation"
    fi
}


# Function to create influxdb  datasource.yaml
create_influx-datasource_yaml() {
    echo -e "${BLUE}Creating InfluxDB-Datasource configuration...${NC}"
    
    cat > "$COMPOSE_PATH/grafana/provisioning/datasources/datasource.yaml" << EOF
# datasource.yaml
apiVersion: 1

datasources:
  - name: InfluxDB
    type: influxdb
    access: proxy
    url: http://$IP_ADDRESS:8086
    isDefault: true
    database: default
    jsonData:
      version: Flux
      organization: "$DEFAULT_ORG"
      defaultBucket: default
      tlsSkipVerify: true
    secureJsonData:
      token: "$INFLUX_TOKEN"
    editable: true
EOF
}

# Function to create prometheus.yml
create_prometheus_yaml() {
    echo -e "${BLUE}Creating prometheus influx_datasource configuration...${NC}"
    
    cat > "$COMPOSE_PATH/prometheus/config/prometheus.yml" << EOF
# my global config
global:
  scrape_interval: 15s
  evaluation_interval: 30s
  body_size_limit: 15MB
  sample_limit: 1500
  target_limit: 30
  label_limit: 30
  label_name_length_limit: 200
  label_value_length_limit: 200
EOF
}


create_docker_compose() {
    step_start "Docker Compose File Creation"

    cat > "$COMPOSE_PATH/docker-compose.yml" << EOF
services:

  grafana:
    container_name: grafana
    image: grafana/grafana-oss:main-ubuntu
    user: "0"
    networks:
      - grafana-monitoring
    volumes:
      - /home/installer/Projects/grafana-monitoring/grafana:/var/lib/grafana
      - /home/installer/Projects/grafana-monitoring/grafana/provisioning:/etc/grafana/provisioning
    ports:
      - "3000:3000"
    restart: unless-stopped
    environment:
      - GF_SECURITY_ADMIN_USER=admin
      - GF_SECURITY_ADMIN_PASSWORD=netscout1
      - GF_USERS_ALLOW_SIGN_UP=false
      - GF_SERVER_ROOT_URL=http://192.168.30.43:3000
      - GF_INSTALL_PLUGINS=grafana-piechart-panel,grafana-clock-panel
      - GF_USERS_DEFAULT_THEME=dark
      - GF_LOG_MODE=console
    depends_on:
      influxdb:
        condition: service_healthy

  influxdb:
    container_name: influxdb
    image: influxdb:latest
    restart: unless-stopped
    ports:
      - 8086:8086
      - 8089:8089/udp
    networks:
      - grafana-monitoring
    volumes:
      - '/home/installer/Projects/grafana-monitoring/influxdb:/var/lib/influxdb2'
    environment:
      - DOCKER_INFLUXDB_INIT_USERNAME='admin'
      - DOCKER_INFLUXDB_INIT_PASSWORD='netscout1'
      - DOCKER_INFLUXDB_INIT_ORG=Netscout
      - DOCKER_INFLUXDB_INIT_BUCKET=default
      - DOCKER_INFLUXDB_INIT_RETENTION=30d
      - DOCKER_INFLUXDB_INIT_ADMIN_TOKEN=MyInfluxToken123
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8086/health"]
      interval: 30s
      timeout: 10s
      retries: 5

  telegraf:
    container_name: telegraf
    restart: unless-stopped
    user: telegraf:992
    networks:
      - grafana-monitoring
    volumes:
      - '/home/installer/Projects/grafana-monitoring/telegraf/kafka/telegraf.conf:/etc/telegraf/telegraf.conf:ro'
      - '/:/hostfs:ro'
      - '/var/run/docker.sock:/var/run/docker.sock'
    environment:
      - HOST_ETC=/hostfs/etc
      - HOST_PROC=/hostfs/proc
      - HOST_SYS=/hostfs/sys
      - HOST_VAR=/hostfs/var
      - HOST_RUN=/hostfs/run
      - HOST_MOUNT_PREFIX=/hostfs
    image: telegraf:latest

  prometheus:
    image: prom/prometheus
    container_name: prometheus
    restart: unless-stopped
    ports:
      - 9090:9090
    volumes:
      - '/home/installer/Projects/grafana-monitoring/prometheus/config/prometheus.yml:/etc/prometheus/prometheus.yml'
    networks:
      - grafana-monitoring

  kafka:
    container_name: kafka
    image: lensesio/box
    restart: unless-stopped
    ports:
      - "9093:9093"
      - "2181:2181"
      - "3030:3030"
      - "8081-8083:8081-8083"
      - "9581-9585:9581-9585"
      - "9092:9092"
    environment:
      - TZ=America/New_York
      - ADV_HOST=192.168.30.43
      - BROWSECONFIGS=1
      - USER=admin
      - PASSWORD=netscout1
      - SAMPLEDATA=0
      - RUN_AS_ROOT=1
      - ENABLE_SSL=1
      - SUPERVISORWEB=1
      - EULA=https://licenses.lenses.io/download/lensesdl?id=985ddcfc-8f48-11ef-9df4-42010af01003
    networks:
      - grafana-monitoring

  portainer:
    image: portainer/portainer-ce:latest
    container_name: portainer
    restart: unless-stopped
    ports:
      - "8000:8000"
      - "9000:9000"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - '/home/installer/Projects/grafana-monitoring/portainer:/data'
    environment:
      - ADMIN_PASSWORD='netscout1'
    networks:
      - grafana-monitoring

  mongodb:
    image: mongo:latest
    container_name: mongodb
    restart: unless-stopped
    networks:
      - grafana-monitoring
    command: 
      - mongod
      - --bind_ip_all
    ports:
      - "27017:27017"
    volumes:
      - ./data/mongodb:/data/db
      - ./data/mongodb-config:/data/configdb
    healthcheck:
      test: echo 'db.runCommand("ping").ok' | mongosh localhost:27017/test --quiet
      interval: 10s
      timeout: 10s
      retries: 5
      start_period: 40s

  dbgate:
    image: dbgate/dbgate:latest
    container_name: dbgate
    restart: unless-stopped
    user: "0:0"  # Root user to bypass permission issues
    networks:
      - grafana-monitoring
    ports:
      - "8080:3000"
    environment:
      - HOME=/tmp  # Set a writable home directory
      - DBGATE_CONNECTIONS_ROOT=/connections
      - CONNECTIONS_ROOT=/connections
      - DBGATE_PERSIST=/app/persistence
    volumes:
      - ./dbgate/connections:/connections
      - ./dbgate/persistence:/app/persistence
      - ./dbgate/data:/app/data
      # Ensure these directories exist and are writable
    depends_on:
      mongodb:
        condition: service_healthy
volumes:
  mongodb-data:
    driver: local
  mongodb-config:
    driver: local
  dbgate-connections:
    driver: local
  dbgate-persistence:
    driver: local

networks:
  grafana-monitoring:
EOF

    if [ $? -eq 0 ]; then
        log "Docker Compose file created at $COMPOSE_PATH/docker-compose.yml"
        step_pass "${Cyan}Docker Compose File Creation"
    else
        step_fail "${RED}Docker Compose File Creation"
    fi
}

start_containers() {
    step_start "${Cyan}Starting Containers"
    pushd "$COMPOSE_PATH" &>> "$LOG_FILE"
    docker compose up -d | tee -a "$LOG_FILE"
    if [ $? -eq 0 ]; then
        log "Docker containers started successfully."
        step_pass "${Cyan}Starting Containers"
    else
        step_fail "${RED}Starting Containers"
    fi
    popd &>> "$LOG_FILE"
}


check_container_status() {
    step_start "Container Status Check"
    pushd "$COMPOSE_PATH" &>> "$LOG_FILE"
    docker compose ps | tee -a "$LOG_FILE"
    if docker compose ps | grep -q "Up"; then
        log "All containers are running."
        step_pass "${Cyan}Container Running..."
    else
        step_fail "${RED}Some containers failed to start."
    fi
    popd &>> "$LOG_FILE"
}

show_summary() {
    
    echo -e "\n${GREEN}Deployment Summary:${NC}" > "$COMPOSE_PATH/apps_url.txt"
    echo -e "${CYAN}Access URLs:${NC}" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "Grafana:     http://$IP_ADDRESS:3000" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "Prometheus:  http://$IP_ADDRESS:9090" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "InfluxDB:    http://$IP_ADDRESS:8086" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "MongoDB:     mongodb://$IP_ADDRESS:27017" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "Kafka UI:    http://$IP_ADDRESS:3030" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "">> "$COMPOSE_PATH/apps_url.txt"
    echo -e "${GREEN} Your InfluxDB & Grafana user: ${CYAN}${DEFAULT_ADMIN} ${GREEN}Password:${CYAN}${DEFAULT_PASSWORD}">> "$COMPOSE_PATH/apps_url.txt"
    echo -e "\n${YELLOW}Usage: ${WHITE}From $COMPOSE_PATH , issue the following commands:">> "$COMPOSE_PATH/apps_url.txt"
    echo -e "${GREEN}To Activate/De-Activate Stack: ${CYAN}docker compose up -d   ${YELLOW}or  ${CYAN}docker compose down">> "$COMPOSE_PATH/apps_url.txt"
    echo -e "${GREEN}To view containers Status: ${CYAN}docker ps">> "$COMPOSE_PATH/apps_url.txt"
    echo -e "${GREEN}To view containers Logs: ${CYAN}docker logs ${YELLOW}container_name">> "$COMPOSE_PATH/apps_url.txt"
    echo -e "${GREEN}To view containers details: ${CYAN}docker inspect ${YELLOW}container_name" >> "$COMPOSE_PATH/apps_url.txt"
    echo -e "${White}">> "$COMPOSE_PATH/apps_url.txt"
}


# ================================
# Main Script Execution
# ================================
log "${CYAN}Starting Deployment Script"

# Check if IP_ADDRESS was passed as an argument; if not, proceed to interactive selection
if [[ -z "$IP_ADDRESS" ]]; then
    log "No IP address provided as argument. Proceeding to interactive selection."
    select_ip_address
else
    log "Using provided IP address Argument: $IP_ADDRESS"
fi
create_secrets
create_env_file
create_telegraf_conf
create_influx-datasource_yaml
create_prometheus_yaml

create_docker_compose
start_containers
check_container_status
show_summary

cat "$COMPOSE_PATH/apps_url.txt">> "$LOG_FILE"
log "${CYAN}Deployment Completed Successfully"
echo -e "${GREEN}Deployment completed! Logs available in ${LOG_FILE}${NC}"
echo -e ""
cat "$COMPOSE_PATH/apps_url.txt"
echo -e "\n${CYAN}To complete the installation, run option 1,2 and 3 of ${YELLOW}Post-Container-Installation-Script.sh"
echo -e "Goodbye..."
export COMPOSE_PATH="$COMPOSE_PATH"
cd "$COMPOSE_PATH"

